#!/usr/bin/env bash

LIB="./lib"
MAIN_JAR_FILE="tools-cli.jar"

CLASSPATH=$(JARS=("$LIB"/*.jar); IFS=:; echo "${JARS[*]}")
JAVA="/usr/bin/env java"

$JAVA --illegal-access=deny -Xmx4g -Dlog4j.configurationFile=log4j2.xml -cp "$CLASSPATH:./$MAIN_JAR_FILE" -jar $MAIN_JAR_FILE $*